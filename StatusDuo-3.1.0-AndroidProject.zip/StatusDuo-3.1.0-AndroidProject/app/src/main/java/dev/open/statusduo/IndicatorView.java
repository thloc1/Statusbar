package dev.open.statusduo;

import android.content.Context;
import android.content.res.Configuration;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.view.Gravity;
import android.view.View;
import android.widget.TextView;

final class IndicatorView extends TextView {
    IndicatorView(Context context) {
        super(context);
        setGravity(Gravity.CENTER);
        setSingleLine(true);
        setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
        setIncludeFontPadding(false);
        setImportantForAccessibility(View.IMPORTANT_FOR_ACCESSIBILITY_NO_HIDE_DESCENDANTS);
        setElevation(dp(4));
    }

    void applyAppearance(Context c) {
        String theme = Prefs.theme(c);
        int opacity = Prefs.opacity(c);
        int bg;
        int fg;
        switch (theme) {
            case "black":
                bg = Color.BLACK;
                fg = Color.WHITE;
                break;
            case "white":
                bg = Color.WHITE;
                fg = Color.BLACK;
                break;
            case "transparent":
                bg = Color.TRANSPARENT;
                fg = isDarkMode(c) ? Color.WHITE : Color.BLACK;
                break;
            case "auto":
                bg = isDarkMode(c) ? Color.BLACK : Color.WHITE;
                fg = isDarkMode(c) ? Color.WHITE : Color.BLACK;
                break;
            default: // glass
                int alpha = Math.max(15, Math.min(255, Math.round(opacity * 2.55f)));
                bg = (alpha << 24) | 0x171A22;
                fg = Color.WHITE;
                break;
        }
        GradientDrawable drawable = new GradientDrawable();
        drawable.setShape(GradientDrawable.RECTANGLE);
        drawable.setCornerRadius(dp(30));
        drawable.setColor(bg);
        if (Prefs.border(c)) {
            int stroke = theme.equals("white") ? 0x55333333 : 0x55FFFFFF;
            drawable.setStroke(dp(1), stroke);
        }
        setBackground(drawable);
        setTextColor(fg);
        float scale = Prefs.scale(c);
        setTextSize(12.5f * scale);
        int horizontal = Math.round(dp(11) * scale);
        int vertical = Math.round(dp(7) * scale);
        setPadding(horizontal, vertical, horizontal, vertical);
    }

    private boolean isDarkMode(Context c) {
        int mode = c.getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK;
        return mode == Configuration.UI_MODE_NIGHT_YES;
    }

    private int dp(float value) {
        return Math.round(value * getResources().getDisplayMetrics().density);
    }
}
