package dev.open.statusduo;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.res.Configuration;
import android.graphics.PixelFormat;
import android.net.ConnectivityManager;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.IBinder;
import android.provider.Settings;
import android.telephony.TelephonyManager;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;

import java.util.Locale;

public class OverlayService extends Service {
    static final String ACTION_REFRESH = "dev.open.statusduo.action.REFRESH";
    static final String ACTION_STOP = "dev.open.statusduo.action.STOP";
    private static final String CHANNEL_ID = "statusduo_overlay";
    private static final int NOTIFICATION_ID = 3101;

    private WindowManager windowManager;
    private WindowManager.LayoutParams params;
    private IndicatorView indicator;
    private BroadcastReceiver systemReceiver;
    private int batteryLevel = -1;
    private boolean charging = false;
    private boolean added = false;

    @Override public void onCreate() {
        super.onCreate();
        Prefs.setDefaults(this);
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        createNotificationChannel();
        registerSystemEvents();
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NOTIFICATION_ID, makeNotification(), android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        } else {
            startForeground(NOTIFICATION_ID, makeNotification());
        }

        if (intent != null && ACTION_STOP.equals(intent.getAction())) {
            Prefs.setOverlayEnabled(this, false);
            stopSelf();
            return START_NOT_STICKY;
        }

        if (!Settings.canDrawOverlays(this)) {
            Prefs.setOverlayEnabled(this, false);
            stopSelf();
            return START_NOT_STICKY;
        }

        Prefs.setOverlayEnabled(this, true);
        ensureIndicator();
        renderIndicator();
        // Deliberately avoid automatic restart loops. The user or Quick Settings can re-enable it.
        return START_NOT_STICKY;
    }

    private void registerSystemEvents() {
        systemReceiver = new BroadcastReceiver() {
            @Override public void onReceive(Context context, Intent intent) {
                if (intent == null) return;
                String action = intent.getAction();
                if (Intent.ACTION_BATTERY_CHANGED.equals(action)) {
                    batteryLevel = readBatteryLevel(intent);
                    int status = intent.getIntExtra(android.os.BatteryManager.EXTRA_STATUS, -1);
                    charging = status == android.os.BatteryManager.BATTERY_STATUS_CHARGING ||
                               status == android.os.BatteryManager.BATTERY_STATUS_FULL;
                    BatteryEstimator.recordSample(OverlayService.this, batteryLevel, charging);
                }
                renderIndicator();
            }
        };

        IntentFilter filter = new IntentFilter();
        filter.addAction(Intent.ACTION_BATTERY_CHANGED);
        filter.addAction(Intent.ACTION_AIRPLANE_MODE_CHANGED);
        filter.addAction(WifiManager.RSSI_CHANGED_ACTION);
        filter.addAction(WifiManager.NETWORK_STATE_CHANGED_ACTION);
        filter.addAction(ConnectivityManager.CONNECTIVITY_ACTION);
        filter.addAction(Intent.ACTION_SCREEN_OFF);
        filter.addAction(Intent.ACTION_USER_PRESENT);
        filter.addAction(Intent.ACTION_CONFIGURATION_CHANGED);
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(systemReceiver, filter, Context.RECEIVER_NOT_EXPORTED);
        } else {
            registerReceiver(systemReceiver, filter);
        }
        Intent sticky = registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
        if (sticky != null) {
            batteryLevel = readBatteryLevel(sticky);
            int status = sticky.getIntExtra(android.os.BatteryManager.EXTRA_STATUS, -1);
            charging = status == android.os.BatteryManager.BATTERY_STATUS_CHARGING || status == android.os.BatteryManager.BATTERY_STATUS_FULL;
            BatteryEstimator.recordSample(this, batteryLevel, charging);
        }
    }

    private int readBatteryLevel(Intent intent) {
        int level = intent.getIntExtra(android.os.BatteryManager.EXTRA_LEVEL, -1);
        int scale = intent.getIntExtra(android.os.BatteryManager.EXTRA_SCALE, 100);
        if (level < 0 || scale <= 0) return -1;
        return Math.round(level * 100f / scale);
    }

    private void ensureIndicator() {
        if (indicator != null && added) return;
        indicator = new IndicatorView(this);
        params = new WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE |
                WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE |
                WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN,
                PixelFormat.TRANSLUCENT);
        applyPosition();
        try {
            windowManager.addView(indicator, params);
            added = true;
        } catch (RuntimeException ex) {
            added = false;
            indicator = null;
            stopSelf();
        }
    }

    private void applyPosition() {
        if (params == null) return;
        boolean landscape = getResources().getConfiguration().orientation == Configuration.ORIENTATION_LANDSCAPE;
        boolean useSide = landscape && Prefs.autoLandscape(this);
        params.gravity = useSide ? (Gravity.TOP | Gravity.START) : (Gravity.TOP | Gravity.CENTER_HORIZONTAL);
        float density = getResources().getDisplayMetrics().density;
        params.x = useSide ? Math.round(12 * density) : 0;
        params.y = Math.round((useSide ? 8 : 5) * density);
    }

    private void renderIndicator() {
        if (indicator == null) return;
        boolean locked = false;
        android.app.KeyguardManager keyguard = (android.app.KeyguardManager) getSystemService(KEYGUARD_SERVICE);
        if (keyguard != null) locked = keyguard.isKeyguardLocked();
        boolean showOnLock = Prefs.showLockscreenExperiment(this);
        indicator.setVisibility(locked && !showOnLock ? View.GONE : View.VISIBLE);
        indicator.applyAppearance(this);
        indicator.setText(makeIndicatorText());
        applyPosition();
        if (added) {
            try { windowManager.updateViewLayout(indicator, params); }
            catch (RuntimeException ignored) { /* The system may have removed the window; user can toggle it again. */ }
        }
    }

    private String makeIndicatorText() {
        boolean airplane = false;
        try { airplane = android.provider.Settings.Global.getInt(getContentResolver(), android.provider.Settings.Global.AIRPLANE_MODE_ON, 0) == 1; }
        catch (RuntimeException ignored) { }
        StringBuilder out = new StringBuilder();
        if (Prefs.showNetwork(this)) {
            if (airplane) out.append("✈");
            else out.append(networkType());
        }
        if (Prefs.showWifi(this) && !airplane) {
            if (out.length() > 0) out.append("  ·  ");
            out.append("Wi-Fi ").append(wifiBars());
        }
        if (Prefs.showBattery(this)) {
            if (out.length() > 0) out.append("   ");
            out.append("▰ ").append(batteryLevel >= 0 ? batteryLevel + "%" : "—");
            if (charging) out.append(" ⚡");
        }
        if (out.length() == 0) out.append("Status Duo");
        return out.toString();
    }

    private String networkType() {
        if (Build.VERSION.SDK_INT >= 24 && android.provider.Settings.Global.getInt(getContentResolver(), android.provider.Settings.Global.AIRPLANE_MODE_ON, 0) == 1) return "✈";
        try {
            if (checkSelfPermission(android.Manifest.permission.READ_PHONE_STATE) != android.content.pm.PackageManager.PERMISSION_GRANTED) return "Mobile";
            TelephonyManager tm = (TelephonyManager) getSystemService(TELEPHONY_SERVICE);
            if (tm == null) return "Mobile";
            int type = tm.getDataNetworkType();
            switch (type) {
                case TelephonyManager.NETWORK_TYPE_NR: return "5G";
                case TelephonyManager.NETWORK_TYPE_LTE: return "4G";
                case TelephonyManager.NETWORK_TYPE_HSPAP:
                case TelephonyManager.NETWORK_TYPE_HSPA:
                case TelephonyManager.NETWORK_TYPE_HSDPA:
                case TelephonyManager.NETWORK_TYPE_HSUPA:
                case TelephonyManager.NETWORK_TYPE_UMTS: return "3G";
                case TelephonyManager.NETWORK_TYPE_EDGE:
                case TelephonyManager.NETWORK_TYPE_GPRS: return "2G";
                default: return "Mobile";
            }
        } catch (RuntimeException ignored) {
            return "Mobile";
        }
    }

    private String wifiBars() {
        try {
            WifiManager wifi = (WifiManager) getApplicationContext().getSystemService(WIFI_SERVICE);
            if (wifi == null || !wifi.isWifiEnabled()) return "—";
            int rssi = wifi.getConnectionInfo().getRssi();
            int level = WifiManager.calculateSignalLevel(rssi, 4);
            switch (level) {
                case 3: return "▂▄▆█";
                case 2: return "▂▄▆";
                case 1: return "▂▄";
                default: return "▂";
            }
        } catch (RuntimeException ignored) {
            return "•";
        }
    }

    private Notification makeNotification() {
        Intent open = new Intent(this, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        PendingIntent pi = PendingIntent.getActivity(this, 0, open, PendingIntent.FLAG_UPDATE_CURRENT | PendingIntent.FLAG_IMMUTABLE);
        return new Notification.Builder(this, CHANNEL_ID)
                .setSmallIcon(R.drawable.ic_statusduo)
                .setContentTitle("Status Duo đang chạy")
                .setContentText("Chạm để mở cài đặt hoặc tắt lớp phủ")
                .setContentIntent(pi)
                .setOngoing(true)
                .setOnlyAlertOnce(true)
                .build();
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, "Status indicator", NotificationManager.IMPORTANCE_LOW);
            channel.setDescription("Thông báo khi lớp phủ trạng thái được bật");
            NotificationManager nm = getSystemService(NotificationManager.class);
            if (nm != null) nm.createNotificationChannel(channel);
        }
    }

    @Override public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        renderIndicator();
    }

    @Override public void onDestroy() {
        Prefs.setOverlayEnabled(this, false);
        if (systemReceiver != null) {
            try { unregisterReceiver(systemReceiver); } catch (IllegalArgumentException ignored) { }
        }
        if (indicator != null && added) {
            try { windowManager.removeView(indicator); } catch (RuntimeException ignored) { }
        }
        added = false;
        stopForeground(STOP_FOREGROUND_REMOVE);
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }
}
