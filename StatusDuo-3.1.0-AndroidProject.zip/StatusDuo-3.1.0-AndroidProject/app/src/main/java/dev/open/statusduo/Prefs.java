package dev.open.statusduo;

import android.content.Context;
import android.content.SharedPreferences;

final class Prefs {
    static final String FILE = "statusduo_preferences";
    static final String PROFILE_DEFAULT = "default";
    static final String PROFILE_GAMING = "gaming";
    static final String PROFILE_MINIMAL = "minimal";
    static final String PROFILE_SAVER = "saver";

    private Prefs() {}

    static SharedPreferences get(Context context) {
        return context.getSharedPreferences(FILE, Context.MODE_PRIVATE);
    }

    static boolean overlayEnabled(Context c) { return get(c).getBoolean("overlay_enabled", false); }
    static void setOverlayEnabled(Context c, boolean enabled) { get(c).edit().putBoolean("overlay_enabled", enabled).apply(); }
    static boolean autoLandscape(Context c) { return get(c).getBoolean("auto_landscape", true); }
    static boolean border(Context c) { return get(c).getBoolean("border", true); }
    static boolean showLockscreenExperiment(Context c) { return get(c).getBoolean("lockscreen_experiment", false); }
    static boolean showNetwork(Context c) { return get(c).getBoolean("show_network", true); }
    static boolean showWifi(Context c) { return get(c).getBoolean("show_wifi", true); }
    static boolean showBattery(Context c) { return get(c).getBoolean("show_battery", true); }
    static String theme(Context c) { return get(c).getString("theme", "glass"); }
    static String profile(Context c) { return get(c).getString("profile", PROFILE_DEFAULT); }
    static float scale(Context c) { return get(c).getFloat("scale", 1.0f); }
    static int opacity(Context c) { return get(c).getInt("opacity", 88); }

    static void applyProfile(Context c, String profile) {
        SharedPreferences.Editor e = get(c).edit().putString("profile", profile);
        switch (profile) {
            case PROFILE_GAMING:
                e.putBoolean("show_network", true)
                 .putBoolean("show_wifi", false)
                 .putBoolean("show_battery", true)
                 .putBoolean("auto_landscape", true)
                 .putBoolean("border", false)
                 .putString("theme", "black")
                 .putFloat("scale", 0.82f)
                 .putInt("opacity", 100);
                break;
            case PROFILE_MINIMAL:
                e.putBoolean("show_network", false)
                 .putBoolean("show_wifi", false)
                 .putBoolean("show_battery", true)
                 .putBoolean("auto_landscape", true)
                 .putBoolean("border", false)
                 .putString("theme", "black")
                 .putFloat("scale", 0.86f)
                 .putInt("opacity", 100);
                break;
            case PROFILE_SAVER:
                e.putBoolean("show_network", false)
                 .putBoolean("show_wifi", false)
                 .putBoolean("show_battery", true)
                 .putBoolean("auto_landscape", true)
                 .putBoolean("border", false)
                 .putString("theme", "black")
                 .putFloat("scale", 0.78f)
                 .putInt("opacity", 100);
                break;
            default:
                e.putBoolean("show_network", true)
                 .putBoolean("show_wifi", true)
                 .putBoolean("show_battery", true)
                 .putBoolean("auto_landscape", true)
                 .putBoolean("border", true)
                 .putString("theme", "glass")
                 .putFloat("scale", 1.0f)
                 .putInt("opacity", 88);
                break;
        }
        e.apply();
    }

    static void setDefaults(Context c) {
        if (!get(c).contains("profile")) applyProfile(c, PROFILE_DEFAULT);
    }
}
