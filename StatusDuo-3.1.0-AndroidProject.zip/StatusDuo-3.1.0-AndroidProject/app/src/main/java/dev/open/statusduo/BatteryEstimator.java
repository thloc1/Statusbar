package dev.open.statusduo;

import android.content.Context;
import android.content.SharedPreferences;

/** Event-driven estimate. No timer or battery polling is used. */
final class BatteryEstimator {
    private BatteryEstimator() {}

    static void recordSample(Context context, int percent, boolean charging) {
        if (percent < 0 || percent > 100) return;
        SharedPreferences p = Prefs.get(context);
        int oldLevel = p.getInt("eta_last_level", -1);
        long oldTime = p.getLong("eta_last_time", 0L);
        boolean oldCharging = p.getBoolean("eta_last_charging", false);
        float average = p.getFloat("eta_minutes_per_percent", -1f);
        int samples = p.getInt("eta_samples", 0);
        long now = System.currentTimeMillis();

        if (!charging || !oldCharging || (oldLevel >= 0 && percent < oldLevel)) {
            samples = 0;
            average = -1f;
        } else if (oldLevel >= 0 && percent > oldLevel && oldTime > 0L) {
            float minutesPerPercent = ((now - oldTime) / 60000f) / (percent - oldLevel);
            if (minutesPerPercent >= 0.15f && minutesPerPercent <= 30f) {
                average = samples == 0 || average < 0 ? minutesPerPercent : (average * 0.65f + minutesPerPercent * 0.35f);
                samples = Math.min(20, samples + 1);
            }
        }
        SharedPreferences.Editor editor = p.edit().putBoolean("eta_last_charging", charging)
                .putInt("eta_samples", samples).putFloat("eta_minutes_per_percent", average);
        if (oldLevel != percent || oldLevel < 0 || oldCharging != charging) {
            editor.putInt("eta_last_level", percent).putLong("eta_last_time", now);
        }
        editor.apply();
    }

    static int minutesToFull(Context context, int percent, boolean charging) {
        if (!charging || percent < 0 || percent >= 100) return -1;
        SharedPreferences p = Prefs.get(context);
        float average = p.getFloat("eta_minutes_per_percent", -1f);
        int samples = p.getInt("eta_samples", 0);
        if (samples < 2 || average <= 0) return -1;
        return Math.max(1, Math.round(average * (100 - percent)));
    }
}
