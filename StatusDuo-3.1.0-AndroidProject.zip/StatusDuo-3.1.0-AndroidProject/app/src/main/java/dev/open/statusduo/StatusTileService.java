package dev.open.statusduo;

import android.content.Intent;
import android.os.Build;
import android.provider.Settings;
import android.service.quicksettings.Tile;
import android.service.quicksettings.TileService;

public class StatusTileService extends TileService {
    @Override public void onStartListening() {
        super.onStartListening();
        updateTileState();
    }

    @Override public void onClick() {
        super.onClick();
        if (!Settings.canDrawOverlays(this)) {
            Intent open = new Intent(this, MainActivity.class).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
            startActivityAndCollapse(open);
            updateTileState();
            return;
        }
        if (Prefs.overlayEnabled(this)) {
            stopService(new Intent(this, OverlayService.class));
            Prefs.setOverlayEnabled(this, false);
        } else {
            Intent service = new Intent(this, OverlayService.class);
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(service); else startService(service);
            Prefs.setOverlayEnabled(this, true);
        }
        updateTileState();
    }

    private void updateTileState() {
        Tile tile = getQsTile();
        if (tile == null) return;
        tile.setState(Prefs.overlayEnabled(this) ? Tile.STATE_ACTIVE : Tile.STATE_INACTIVE);
        tile.setLabel("Status Duo");
        tile.setSubtitle(Prefs.overlayEnabled(this) ? "Đang bật" : "Đang tắt");
        tile.updateTile();
    }
}
