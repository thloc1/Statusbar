package dev.open.statusduo;

import android.Manifest;
import android.app.Activity;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.BatteryManager;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Locale;

public class MainActivity extends Activity {
    private static final int REQUEST_PHONE = 120;
    private static final int REQUEST_NOTIFICATIONS = 121;
    private LinearLayout page;
    private TextView stateText;
    private TextView batteryText;
    private TextView profileText;
    private IndicatorView preview;
    private Spinner themeSpinner;
    private CheckBox borderSwitch;
    private CheckBox landscapeSwitch;
    private CheckBox detailsSwitch;
    private CheckBox lockscreenSwitch;
    private SeekBar opacityBar;
    private SeekBar sizeBar;
    private boolean building = false;
    private BroadcastReceiver batteryReceiver;

    @Override public void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        Prefs.setDefaults(this);
        buildUi();
        refreshControls();
        registerBatteryReceiver();
    }

    @Override protected void onResume() {
        super.onResume();
        updateStatus();
        updateBatteryText(null);
    }

    private int dp(float value) { return Math.round(value * getResources().getDisplayMetrics().density); }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(Color.rgb(17, 20, 27));
        page = new LinearLayout(this);
        page.setOrientation(LinearLayout.VERTICAL);
        page.setPadding(dp(18), dp(38), dp(18), dp(28));
        scroll.addView(page, new ScrollView.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.WRAP_CONTENT));
        setContentView(scroll);

        TextView title = text("Status Duo 3.1", 26, 0xFFFFFFFF, true);
        page.addView(title);
        TextView subtitle = text("Bản thử nghiệm độc lập · Ưu tiên nhẹ và riêng tư", 13, 0xFFB5BCCB, false);
        LinearLayout.LayoutParams subLp = new LinearLayout.LayoutParams(-1, -2);
        subLp.topMargin = dp(5);
        subLp.bottomMargin = dp(16);
        page.addView(subtitle, subLp);

        stateText = text("Lớp phủ đang tắt", 14, 0xFFB8E2FF, true);
        page.addView(stateText, gapTop(0));
        Button toggle = button("BẬT / TẮT LỚP PHỦ");
        toggle.setOnClickListener(v -> toggleOverlay());
        page.addView(toggle, gapTop(10));
        Button phonePermission = button("Cho phép đọc loại mạng di động (tùy chọn)");
        phonePermission.setOnClickListener(v -> requestPhonePermission());
        page.addView(phonePermission, gapTop(7));

        addSection("XEM TRƯỚC");
        preview = new IndicatorView(this);
        preview.setText("5G   ·   Wi-Fi ▂▄▆█   ▰ 86%");
        LinearLayout previewWrap = new LinearLayout(this);
        previewWrap.setGravity(Gravity.CENTER);
        previewWrap.setPadding(0, dp(14), 0, dp(14));
        previewWrap.addView(preview, new LinearLayout.LayoutParams(-2, -2));
        previewWrap.setBackground(rounded(0xFF202631, dp(16), 0xFF3A4557));
        page.addView(previewWrap, gapTop(6));
        TextView previewTip = text("Xem trước chỉ là View trong ứng dụng, không tạo thêm lớp phủ hệ thống.", 12, 0xFF9EA8B8, false);
        page.addView(previewTip, gapTop(6));

        addSection("HỒ SƠ NHANH");
        profileText = text("Hồ sơ hiện tại: Mặc định", 13, 0xFFB5BCCB, false);
        page.addView(profileText, gapTop(2));
        LinearLayout profiles1 = horizontal();
        profiles1.addView(profileButton("Mặc định", Prefs.PROFILE_DEFAULT), weightLp());
        profiles1.addView(profileButton("Gaming", Prefs.PROFILE_GAMING), weightLp());
        page.addView(profiles1, gapTop(8));
        LinearLayout profiles2 = horizontal();
        profiles2.addView(profileButton("Tối giản", Prefs.PROFILE_MINIMAL), weightLp());
        profiles2.addView(profileButton("Tiết kiệm", Prefs.PROFILE_SAVER), weightLp());
        page.addView(profiles2, gapTop(7));

        addSection("GIAO DIỆN");
        page.addView(text("Kiểu nền", 14, 0xFFE9EDF5, true), gapTop(5));
        String[] themeNames = {"Glass · bán trong suốt", "AMOLED · đen", "Trắng", "Trong suốt", "Auto · theo giao diện"};
        themeSpinner = new Spinner(this);
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this, android.R.layout.simple_spinner_item, themeNames);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        themeSpinner.setAdapter(adapter);
        themeSpinner.setOnItemSelectedListener(new android.widget.AdapterView.OnItemSelectedListener() {
            @Override public void onItemSelected(android.widget.AdapterView<?> parent, View view, int position, long id) {
                if (building) return;
                String[] values = {"glass", "black", "white", "transparent", "auto"};
                Prefs.get(MainActivity.this).edit().putString("theme", values[position]).apply();
                updatePreviewAndOverlay();
            }
            @Override public void onNothingSelected(android.widget.AdapterView<?> parent) { }
        });
        page.addView(themeSpinner, gapTop(5));

        borderSwitch = check("Viền mảnh quanh chỉ báo");
        borderSwitch.setOnCheckedChangeListener((button, checked) -> { if (!building) { Prefs.get(this).edit().putBoolean("border", checked).apply(); updatePreviewAndOverlay(); } });
        page.addView(borderSwitch, gapTop(8));

        page.addView(text("Độ trong suốt nền Glass", 14, 0xFFE9EDF5, true), gapTop(10));
        opacityBar = new SeekBar(this);
        opacityBar.setMax(100);
        opacityBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (!building && fromUser) { Prefs.get(MainActivity.this).edit().putInt("opacity", Math.max(10, progress)).apply(); updatePreviewAndOverlay(); }
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) { }
            @Override public void onStopTrackingTouch(SeekBar seekBar) { }
        });
        page.addView(opacityBar, gapTop(3));

        page.addView(text("Kích thước chỉ báo", 14, 0xFFE9EDF5, true), gapTop(8));
        sizeBar = new SeekBar(this);
        sizeBar.setMax(60);
        sizeBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                if (!building && fromUser) { Prefs.get(MainActivity.this).edit().putFloat("scale", 0.7f + progress / 100f).apply(); updatePreviewAndOverlay(); }
            }
            @Override public void onStartTrackingTouch(SeekBar seekBar) { }
            @Override public void onStopTrackingTouch(SeekBar seekBar) { }
        });
        page.addView(sizeBar, gapTop(3));

        addSection("TỐI ƯU & TƯƠNG THÍCH");
        landscapeSwitch = check("Tự đổi vị trí khi xoay ngang");
        landscapeSwitch.setOnCheckedChangeListener((button, checked) -> { if (!building) { Prefs.get(this).edit().putBoolean("auto_landscape", checked).apply(); updatePreviewAndOverlay(); } });
        page.addView(landscapeSwitch, gapTop(5));
        detailsSwitch = check("Hiện thông tin pin mở rộng");
        detailsSwitch.setOnCheckedChangeListener((button, checked) -> { if (!building) { Prefs.get(this).edit().putBoolean("battery_details", checked).apply(); updateBatteryText(null); } });
        page.addView(detailsSwitch, gapTop(5));
        lockscreenSwitch = check("Thử nghiệm màn hình khóa");
        lockscreenSwitch.setOnCheckedChangeListener((button, checked) -> {
            if (!building) {
                Prefs.get(this).edit().putBoolean("lockscreen_experiment", checked).apply();
                Toast.makeText(this, checked ? "Đã bật thử nghiệm; One UI có thể vẫn chặn lớp phủ." : "Đã tắt thử nghiệm màn hình khóa.", Toast.LENGTH_LONG).show();
                updatePreviewAndOverlay();
            }
        });
        page.addView(lockscreenSwitch, gapTop(5));
        TextView lockTip = text("Màn hình khóa phụ thuộc Android/One UI. Ứng dụng không bỏ qua bảo mật màn hình khóa và không dùng Accessibility.", 12, 0xFF9EA8B8, false);
        page.addView(lockTip, gapTop(2));

        addSection("THÔNG TIN PIN");
        batteryText = text("Đang đọc dữ liệu pin…", 14, 0xFFE9EDF5, false);
        batteryText.setPadding(dp(12), dp(12), dp(12), dp(12));
        batteryText.setBackground(rounded(0xFF202631, dp(14), 0xFF3A4557));
        page.addView(batteryText, gapTop(5));
        TextView batteryTip = text("Thời gian sạc chỉ hiện sau khi quan sát đủ các lần tăng phần trăm; ứng dụng không đoán khi thiếu dữ liệu.", 12, 0xFF9EA8B8, false);
        page.addView(batteryTip, gapTop(5));

        addSection("QUICK SETTINGS");
        page.addView(text("Mở bảng Cài đặt nhanh của Samsung → Sửa nút → kéo ô “Status Duo” vào bảng. Chạm ô để bật/tắt lớp phủ.", 13, 0xFFD0D6E2, false), gapTop(4));

        addSection("QUYỀN RIÊNG TƯ");
        page.addView(text("Không dùng quyền Internet, vị trí, danh bạ, camera, micro hoặc Trợ năng. Quyền đọc trạng thái điện thoại chỉ cần nếu bạn muốn hiện loại mạng di động.", 13, 0xFFD0D6E2, false), gapTop(4));

        TextView footer = text("Status Duo là prototype độc lập, không phải bản phát hành chính thức hoặc bản cập nhật chữ ký của O.status.", 11, 0xFF8791A2, false);
        page.addView(footer, gapTop(20));
    }

    private void refreshControls() {
        building = true;
        String theme = Prefs.theme(this);
        String[] values = {"glass", "black", "white", "transparent", "auto"};
        int selected = 0;
        for (int i = 0; i < values.length; i++) if (values[i].equals(theme)) selected = i;
        if (themeSpinner != null) themeSpinner.setSelection(selected);
        if (borderSwitch != null) borderSwitch.setChecked(Prefs.border(this));
        if (landscapeSwitch != null) landscapeSwitch.setChecked(Prefs.autoLandscape(this));
        if (detailsSwitch != null) detailsSwitch.setChecked(Prefs.get(this).getBoolean("battery_details", true));
        if (lockscreenSwitch != null) lockscreenSwitch.setChecked(Prefs.showLockscreenExperiment(this));
        if (opacityBar != null) opacityBar.setProgress(Prefs.opacity(this));
        if (sizeBar != null) sizeBar.setProgress(Math.max(0, Math.min(60, Math.round((Prefs.scale(this) - 0.7f) * 100))));
        if (profileText != null) profileText.setText("Hồ sơ hiện tại: " + profileName(Prefs.profile(this)));
        building = false;
        updatePreviewAndOverlay();
    }

    private void toggleOverlay() {
        if (!Settings.canDrawOverlays(this)) {
            Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:" + getPackageName()));
            startActivity(intent);
            Toast.makeText(this, "Hãy cho phép hiển thị trên ứng dụng khác, rồi quay lại nhấn nút bật.", Toast.LENGTH_LONG).show();
            return;
        }
        if (Prefs.overlayEnabled(this)) {
            stopService(new Intent(this, OverlayService.class));
            Prefs.setOverlayEnabled(this, false);
        } else {
            if (Build.VERSION.SDK_INT >= 33 && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS) != PackageManager.PERMISSION_GRANTED) {
                requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQUEST_NOTIFICATIONS);
            }
            Intent service = new Intent(this, OverlayService.class);
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(service); else startService(service);
            Prefs.setOverlayEnabled(this, true);
        }
        updateStatus();
    }

    private void requestPhonePermission() {
        if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.READ_PHONE_STATE) != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.READ_PHONE_STATE}, REQUEST_PHONE);
        } else {
            Toast.makeText(this, "Quyền trạng thái điện thoại đã được cấp.", Toast.LENGTH_SHORT).show();
        }
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQUEST_PHONE) {
            Toast.makeText(this, grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED ? "Đã bật thông tin mạng di động." : "Bạn vẫn có thể dùng Wi-Fi và pin mà không cấp quyền này.", Toast.LENGTH_LONG).show();
            updatePreviewAndOverlay();
        }
    }

    private void updatePreviewAndOverlay() {
        if (preview != null) {
            preview.applyAppearance(this);
            preview.setText(previewText());
        }
        if (Prefs.overlayEnabled(this)) {
            Intent intent = new Intent(this, OverlayService.class).setAction(OverlayService.ACTION_REFRESH);
            if (Build.VERSION.SDK_INT >= 26) startForegroundService(intent); else startService(intent);
        }
        updateStatus();
    }

    private String previewText() {
        StringBuilder s = new StringBuilder();
        if (Prefs.showNetwork(this)) s.append("5G");
        if (Prefs.showWifi(this)) { if (s.length() > 0) s.append("  ·  "); s.append("Wi-Fi ▂▄▆█"); }
        if (Prefs.showBattery(this)) { if (s.length() > 0) s.append("   "); s.append("▰ 86%"); }
        return s.length() == 0 ? "Status Duo" : s.toString();
    }

    private void updateStatus() {
        if (stateText != null) stateText.setText(Prefs.overlayEnabled(this) ? "● Lớp phủ đang bật" : "○ Lớp phủ đang tắt");
        if (profileText != null) profileText.setText("Hồ sơ hiện tại: " + profileName(Prefs.profile(this)));
    }

    private void registerBatteryReceiver() {
        batteryReceiver = new BroadcastReceiver() {
            @Override public void onReceive(Context context, Intent intent) { updateBatteryText(intent); }
        };
        IntentFilter filter = new IntentFilter(Intent.ACTION_BATTERY_CHANGED);
        if (Build.VERSION.SDK_INT >= 33) registerReceiver(batteryReceiver, filter, Context.RECEIVER_NOT_EXPORTED);
        else registerReceiver(batteryReceiver, filter);
        Intent current = registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
        if (current != null) updateBatteryText(current);
    }

    private void updateBatteryText(Intent intent) {
        if (batteryText == null) return;
        Intent data = intent;
        if (data == null) data = registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
        if (data == null) return;
        int level = data.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
        int scale = data.getIntExtra(BatteryManager.EXTRA_SCALE, 100);
        int percent = (level >= 0 && scale > 0) ? Math.round(level * 100f / scale) : -1;
        int temp = data.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, -1);
        int voltage = data.getIntExtra(BatteryManager.EXTRA_VOLTAGE, -1);
        int status = data.getIntExtra(BatteryManager.EXTRA_STATUS, -1);
        boolean charging = status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL;
        String statusText;
        if (status == BatteryManager.BATTERY_STATUS_FULL) statusText = "Đầy";
        else if (charging) statusText = "Đang sạc";
        else if (status == BatteryManager.BATTERY_STATUS_DISCHARGING) statusText = "Đang dùng pin";
        else statusText = "Không rõ";
        StringBuilder text = new StringBuilder();
        text.append("Mức pin: ").append(percent >= 0 ? percent + "%" : "Không khả dụng").append('\n');
        text.append("Trạng thái: ").append(statusText).append('\n');
        text.append("Nhiệt độ: ").append(temp >= 0 ? String.format(Locale.getDefault(), "%.1f°C", temp / 10f) : "Không khả dụng").append('\n');
        text.append("Điện áp: ").append(voltage > 0 ? String.format(Locale.getDefault(), "%.2f V", voltage / 1000f) : "Không khả dụng");
        if (Prefs.get(this).getBoolean("battery_details", true)) {
            BatteryEstimator.recordSample(this, percent, charging);
            int eta = BatteryEstimator.minutesToFull(this, percent, charging);
            text.append('\n').append("Thời gian đến 100%: ");
            if (!charging) text.append("— (không sạc)");
            else if (percent >= 100) text.append("Đã đầy");
            else if (eta > 0) text.append(formatDuration(eta));
            else text.append("Đang thu thập dữ liệu sạc");
        }
        batteryText.setText(text.toString());
    }

    private String formatDuration(int minutes) {
        if (minutes < 60) return "≈ " + minutes + " phút";
        return "≈ " + (minutes / 60) + " giờ " + (minutes % 60) + " phút";
    }

    private Button profileButton(String label, String profile) {
        Button b = button(label);
        b.setOnClickListener(v -> { Prefs.applyProfile(this, profile); refreshControls(); });
        return b;
    }

    private void addSection(String label) {
        TextView t = text(label, 12, 0xFF9EC8E8, true);
        t.setLetterSpacing(0.08f);
        LinearLayout.LayoutParams lp = gapTop(22);
        lp.bottomMargin = dp(4);
        page.addView(t, lp);
    }

    private TextView text(String value, float size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(size);
        t.setTextColor(color);
        if (bold) t.setTypeface(android.graphics.Typeface.DEFAULT, android.graphics.Typeface.BOLD);
        return t;
    }

    private Button button(String label) {
        Button b = new Button(this);
        b.setText(label);
        b.setTextSize(13);
        b.setAllCaps(false);
        b.setTextColor(0xFFF6FAFF);
        b.setBackground(rounded(0xFF2B3544, dp(12), 0xFF435167));
        b.setMinHeight(dp(44));
        return b;
    }

    private CheckBox check(String label) {
        CheckBox c = new CheckBox(this);
        c.setText(label);
        c.setTextColor(0xFFE9EDF5);
        c.setTextSize(14);
        c.setButtonTintList(android.content.res.ColorStateList.valueOf(0xFFA7D8FF));
        return c;
    }

    private LinearLayout horizontal() {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        return row;
    }

    private LinearLayout.LayoutParams weightLp() {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -2, 1f);
        lp.setMargins(dp(3), 0, dp(3), 0);
        return lp;
    }

    private LinearLayout.LayoutParams gapTop(int dpValue) {
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, -2);
        lp.topMargin = dp(dpValue);
        return lp;
    }

    private GradientDrawable rounded(int fill, int radius, int stroke) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(fill);
        d.setCornerRadius(radius);
        d.setStroke(dp(1), stroke);
        return d;
    }

    private String profileName(String value) {
        switch (value) {
            case Prefs.PROFILE_GAMING: return "Gaming";
            case Prefs.PROFILE_MINIMAL: return "Tối giản";
            case Prefs.PROFILE_SAVER: return "Tiết kiệm";
            default: return "Mặc định";
        }
    }

    @Override protected void onDestroy() {
        if (batteryReceiver != null) {
            try { unregisterReceiver(batteryReceiver); } catch (IllegalArgumentException ignored) { }
        }
        super.onDestroy();
    }
}
