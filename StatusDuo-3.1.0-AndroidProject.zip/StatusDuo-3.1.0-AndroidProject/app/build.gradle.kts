plugins {
    id("com.android.application")
}

android {
    namespace = "dev.open.statusduo"
    compileSdk = 35

    defaultConfig {
        applicationId = "dev.open.statusduo"
        minSdk = 29
        targetSdk = 35
        versionCode = 30100
        versionName = "3.1.0-prototype"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }

    buildTypes {
        release {
            isMinifyEnabled = false
        }
        debug {
            applicationIdSuffix = ".debug"
            versionNameSuffix = "-debug"
        }
    }
}
