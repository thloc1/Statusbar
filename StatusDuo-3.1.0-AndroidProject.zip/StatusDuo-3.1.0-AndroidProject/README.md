# Status Duo 3.1.0 — Independent Android Prototype

This is a clean-room Android Studio project built from scratch to demonstrate the requested status-overlay ideas. It does **not** include or modify the original O.status source or APK and is not an official O.status release.

## Implemented in this prototype

- Real, non-interactive Android overlay using `TYPE_APPLICATION_OVERLAY`.
- Preview inside the settings Activity, without creating a second system overlay.
- Glass, AMOLED black, white, transparent and Auto appearance modes; opacity, border and size controls.
- Quick profiles: Default, Gaming, Minimal and Saver.
- Orientation-aware overlay positioning when landscape mode is enabled.
- Event-driven updates from battery, Wi-Fi/network and system broadcasts; no periodic polling loop or animation loop.
- Battery level, charging state, temperature and voltage; charge ETA is shown only after observing enough level-change samples.
- Quick Settings Tile for starting/stopping the overlay.
- Optional lock-screen experiment. It does not try to bypass keyguard restrictions; Android/One UI may hide the overlay while locked.
- No `INTERNET`, location, Accessibility, contacts, camera or microphone permission is declared.

## Important limits

- This is an independent prototype, **not an APK update for `com.catch7ng.ostatus`**. It has its own application ID, `dev.open.statusduo`, so it can be installed separately.
- The `READ_PHONE_STATE` permission is optional and used only to display the mobile network type. The basic Wi-Fi/battery overlay should still be usable if it is denied.
- The lock-screen option is experimental and device-dependent. It never asks for Accessibility and does not bypass the device lock screen.
- Charge-time estimates require at least two usable observed charging intervals; the estimate may remain unavailable on short tests or devices that do not report useful changes.
- This source was generated in an environment without the Android SDK/Gradle installed, so it has **not** been compiled or tested on a physical device here. Build and test it in Android Studio before relying on it.

## Build an APK in Android Studio

1. Extract the ZIP on a computer with Android Studio.
2. Open the extracted `StatusDuo-3.1.0-AndroidProject` folder as a project.
3. Accept Gradle sync and install Android SDK Platform 35 / Build Tools when prompted.
4. Use **Build → Build APK(s)**. The debug APK should appear under `app/build/outputs/apk/debug/`.
5. Install the APK on a test device. Grant **Display over other apps** when the app asks. The mobile-network permission is optional.
6. To use Quick Settings, edit the Quick Settings panel and add the **Status Duo** tile.

The Gradle plugin may need an Internet connection during the first Android Studio sync. No analytics endpoint or app Internet permission is included in this app.

## Version

- Version name: `3.1.0-prototype`
- Version code: `30100`
- Minimum Android: 10 (API 29)
- Target SDK: 35
- Language: Java
