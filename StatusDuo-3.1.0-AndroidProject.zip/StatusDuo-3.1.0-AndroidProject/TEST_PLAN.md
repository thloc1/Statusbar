# Device test checklist

- [ ] Install on Android 10+ and launch without granting phone-state permission.
- [ ] Grant overlay permission and turn the indicator on/off repeatedly.
- [ ] Confirm the preview changes themes without creating another overlay.
- [ ] Rotate portrait ↔ landscape and verify position changes without covering important game controls.
- [ ] Test Default, Gaming, Minimal and Saver profiles.
- [ ] Toggle Wi-Fi; compare the signal glyph with connection changes.
- [ ] Charge the phone and verify temperature/voltage appear when Android supplies them.
- [ ] Confirm the ETA stays unavailable until enough plausible sample points exist.
- [ ] Add the Quick Settings tile and test toggling it from the shade.
- [ ] Test with One UI battery/background restrictions enabled and disabled; verify no restart loop.
- [ ] Test lock-screen option on a secure lock screen; confirm the OS security screen remains usable.
- [ ] Inspect App info → Permissions and verify no Internet, location, Accessibility, camera or microphone permission is present.
- [ ] Leave the overlay active for several hours and check memory, battery use and behavior after rotation/screen off.
