# Feature notes

## UI and preview
- Appearance mode is stored locally in SharedPreferences.
- The sample preview is an ordinary TextView-derived view in the settings Activity, not a WindowManager overlay.
- Overlay themes, border, opacity and size are applied without external image, font or network dependencies.

## Performance model
- The overlay refreshes on relevant system broadcasts rather than a repeating timer.
- No continuous animation is enabled.
- Battery ETA is sampled when Android reports battery changes, and only calculated after multiple plausible charge increments.
- Foreground-service restart loops are intentionally not used. If One UI stops the service, the user can re-enable it from the app or Quick Settings.

## Quick Settings
- The tile opens settings when the overlay permission has not been granted; otherwise it toggles the service.
- As on stock Android, the tile must be added by the user through the Quick Settings editor.

## Lock screen
- The option is explicitly experimental. The app only opts into leaving its non-touchable overlay view visible when keyguard is locked; the OS may still suppress it. It does not call `showWhenLocked`, use Accessibility, or request device-admin privileges.
