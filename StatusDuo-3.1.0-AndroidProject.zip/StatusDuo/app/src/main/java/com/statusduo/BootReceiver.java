package com.statusduo;
import android.content.*;import android.os.*;import android.provider.Settings;
public class BootReceiver extends BroadcastReceiver{public void onReceive(Context c,Intent i){if(Intent.ACTION_BOOT_COMPLETED.equals(i.getAction())&&Settings.canDrawOverlays(c)){Intent s=new Intent(c,OverlayService.class);if(Build.VERSION.SDK_INT>=26)c.startForegroundService(s);else c.startService(s);}}}
