package com.statusduo;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.pm.ServiceInfo;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.net.ConnectivityManager;
import android.net.Network;
import android.net.NetworkCapabilities;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.BatteryManager;
import android.os.Build;
import android.os.IBinder;
import android.telephony.PhoneStateListener;
import android.telephony.SignalStrength;
import android.telephony.TelephonyManager;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;


/** A lightweight, iPhone-Duo-inspired combined battery/Wi-Fi/cellular indicator. */
public class OverlayService extends Service {
    public static volatile boolean running = false;
    private WindowManager windowManager;
    private DuoView indicator;
    private WindowManager.LayoutParams layoutParams;
    private boolean expanded = false;

    private int batteryPercent = 0;
    private int batteryTemperatureC = -1;
    private boolean isCharging = false;
    private boolean wifiConnected = false;
    private int wifiLevel = 0;       // 0..4
    private int cellularLevel = -1;  // 0..4; -1 means permission/API data unavailable

    private WifiManager wifiManager;
    private TelephonyManager telephonyManager;
    private PhoneStateListener phoneStateListener;
    private boolean receiverRegistered = false;

    private final BroadcastReceiver stateReceiver = new BroadcastReceiver() {
        @Override public void onReceive(Context context, Intent intent) {
            if (intent == null) return;
            String action = intent.getAction();
            if (Intent.ACTION_BATTERY_CHANGED.equals(action)) {
                readBattery(intent);
            } else if (Intent.ACTION_POWER_CONNECTED.equals(action)) {
                isCharging = true;
                readBattery(null);
            } else if (Intent.ACTION_POWER_DISCONNECTED.equals(action)) {
                isCharging = false;
                readBattery(null);
            } else {
                readWifi();
            }
            redraw();
        }
    };

    @Override public void onCreate() {
        super.onCreate();
        running = true;
        createNotificationChannel();
        Notification notification = buildNotification();
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(31, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        } else {
            startForeground(31, notification);
        }
        wifiManager = (WifiManager) getApplicationContext().getSystemService(WIFI_SERVICE);
        readBattery(registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED)));
        readWifi();
        registerStateReceiver();
        startCellularListener();
        showIndicator();
    }

    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            NotificationChannel channel = new NotificationChannel(
                    "statusduo", "Status Duo indicator", NotificationManager.IMPORTANCE_LOW);
            channel.setDescription("Keeps the compact status indicator running");
            ((NotificationManager) getSystemService(NOTIFICATION_SERVICE)).createNotificationChannel(channel);
        }
    }

    private Notification buildNotification() {
        Intent open = new Intent(this, MainActivity.class);
        PendingIntent pending = PendingIntent.getActivity(this, 0, open,
                PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
        Notification.Builder builder = Build.VERSION.SDK_INT >= 26
                ? new Notification.Builder(this, "statusduo")
                : new Notification.Builder(this);
        return builder.setSmallIcon(android.R.drawable.ic_menu_info_details)
                .setContentTitle("Status Duo đang chạy")
                .setContentText("Pin • Wi‑Fi • Sóng di động — chạm biểu tượng để xem chi tiết")
                .setContentIntent(pending)
                .setOngoing(true)
                .build();
    }

    private void registerStateReceiver() {
        IntentFilter filter = new IntentFilter();
        filter.addAction(Intent.ACTION_BATTERY_CHANGED);
        filter.addAction(Intent.ACTION_POWER_CONNECTED);
        filter.addAction(Intent.ACTION_POWER_DISCONNECTED);
        filter.addAction(WifiManager.RSSI_CHANGED_ACTION);
        filter.addAction(WifiManager.NETWORK_STATE_CHANGED_ACTION);
        filter.addAction(WifiManager.WIFI_STATE_CHANGED_ACTION);
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(stateReceiver, filter, Context.RECEIVER_NOT_EXPORTED);
        } else {
            registerReceiver(stateReceiver, filter);
        }
        receiverRegistered = true;
    }

    private void readBattery(Intent intent) {
        if (intent == null) {
            intent = registerReceiver(null, new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
        }
        if (intent == null) return;
        int level = intent.getIntExtra(BatteryManager.EXTRA_LEVEL, -1);
        int scale = intent.getIntExtra(BatteryManager.EXTRA_SCALE, -1);
        if (level >= 0 && scale > 0) batteryPercent = Math.max(0, Math.min(100, Math.round(level * 100f / scale)));
        int status = intent.getIntExtra(BatteryManager.EXTRA_STATUS, -1);
        isCharging = status == BatteryManager.BATTERY_STATUS_CHARGING || status == BatteryManager.BATTERY_STATUS_FULL;
        int temp = intent.getIntExtra(BatteryManager.EXTRA_TEMPERATURE, -1);
        batteryTemperatureC = temp > 0 ? Math.round(temp / 10f) : -1;
    }

    @SuppressWarnings("deprecation")
    private void readWifi() {
        if (wifiManager == null) {
            wifiConnected = false;
            wifiLevel = 0;
            return;
        }
        try {
            if (!wifiManager.isWifiEnabled()) {
                wifiConnected = false;
                wifiLevel = 0;
                return;
            }
            WifiInfo info = wifiManager.getConnectionInfo();
            ConnectivityManager connectivity = (ConnectivityManager) getSystemService(CONNECTIVITY_SERVICE);
            Network activeNetwork = connectivity != null ? connectivity.getActiveNetwork() : null;
            NetworkCapabilities capabilities = connectivity != null && activeNetwork != null
                    ? connectivity.getNetworkCapabilities(activeNetwork) : null;
            wifiConnected = capabilities != null
                    && capabilities.hasTransport(NetworkCapabilities.TRANSPORT_WIFI)
                    && info != null && info.getRssi() > -127;
            int rssi = info != null ? info.getRssi() : -127;
            wifiLevel = wifiConnected ? rssiToLevel(rssi) : 0;
        } catch (SecurityException ignored) {
            wifiConnected = false;
            wifiLevel = 0;
        }
    }

    private int rssiToLevel(int rssi) {
        if (rssi <= -100) return 0;
        if (rssi >= -50) return 4;
        return Math.max(0, Math.min(4, (rssi + 100) * 4 / 50));
    }

    @SuppressWarnings("deprecation")
    private void startCellularListener() {
        if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(android.Manifest.permission.READ_PHONE_STATE)
                != android.content.pm.PackageManager.PERMISSION_GRANTED) {
            cellularLevel = -1;
            return;
        }
        try {
            telephonyManager = (TelephonyManager) getSystemService(TELEPHONY_SERVICE);
            if (telephonyManager == null) return;
            phoneStateListener = new PhoneStateListener() {
                @Override public void onSignalStrengthsChanged(SignalStrength signalStrength) {
                    super.onSignalStrengthsChanged(signalStrength);
                    if (signalStrength != null) cellularLevel = Math.max(0, Math.min(4, signalStrength.getLevel()));
                    redraw();
                }
            };
            telephonyManager.listen(phoneStateListener, PhoneStateListener.LISTEN_SIGNAL_STRENGTHS);
            SignalStrength initial = telephonyManager.getSignalStrength();
            if (initial != null) cellularLevel = Math.max(0, Math.min(4, initial.getLevel()));
        } catch (RuntimeException ignored) {
            cellularLevel = -1;
        }
    }

    private void showIndicator() {
        windowManager = (WindowManager) getSystemService(WINDOW_SERVICE);
        indicator = new DuoView(this);
        int type = Build.VERSION.SDK_INT >= 26
                ? WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY
                : WindowManager.LayoutParams.TYPE_PHONE;
        layoutParams = new WindowManager.LayoutParams(dp(44), dp(44), type,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                        | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                android.graphics.PixelFormat.TRANSLUCENT);
        layoutParams.gravity = Gravity.TOP | Gravity.RIGHT;
        layoutParams.x = dp(8);
        layoutParams.y = statusBarHeight() + dp(2);
        try {
            windowManager.addView(indicator, layoutParams);
        } catch (Exception e) {
            stopSelf();
        }
    }

    private int dp(float value) {
        return (int) (value * getResources().getDisplayMetrics().density + 0.5f);
    }

    private int statusBarHeight() {
        int id = getResources().getIdentifier("status_bar_height", "dimen", "android");
        return id > 0 ? getResources().getDimensionPixelSize(id) : dp(24);
    }

    private void redraw() {
        if (indicator != null) indicator.postInvalidate();
    }

    private String wifiLabel() {
        if (!wifiConnected) return "Tắt / chưa kết nối";
        if (wifiLevel >= 4) return "Rất mạnh";
        if (wifiLevel >= 3) return "Mạnh";
        if (wifiLevel >= 2) return "Trung bình";
        return "Yếu";
    }

    private String cellLabel() {
        if (cellularLevel < 0) return "Cần quyền trạng thái điện thoại";
        if (cellularLevel >= 4) return "Rất mạnh";
        if (cellularLevel >= 3) return "Mạnh";
        if (cellularLevel >= 2) return "Trung bình";
        if (cellularLevel == 1) return "Yếu";
        return "Không có sóng / chưa đọc được";
    }

    private void updateWindowSize() {
        if (windowManager == null || indicator == null || layoutParams == null) return;
        layoutParams.width = dp(expanded ? 258 : 44);
        layoutParams.height = dp(expanded ? 86 : 44);
        layoutParams.gravity = Gravity.TOP | Gravity.RIGHT;
        layoutParams.x = dp(8);
        layoutParams.y = statusBarHeight() + dp(2);
        try {
            windowManager.updateViewLayout(indicator, layoutParams);
            indicator.invalidate();
        } catch (Exception ignored) { }
    }

    @Override public int onStartCommand(Intent intent, int flags, int startId) {
        return START_STICKY;
    }

    @Override public void onDestroy() {
        running = false;
        if (receiverRegistered) {
            try { unregisterReceiver(stateReceiver); } catch (Exception ignored) { }
            receiverRegistered = false;
        }
        if (telephonyManager != null && phoneStateListener != null) {
            try { telephonyManager.listen(phoneStateListener, PhoneStateListener.LISTEN_NONE); }
            catch (Exception ignored) { }
        }
        if (indicator != null && windowManager != null) {
            try { windowManager.removeView(indicator); } catch (Exception ignored) { }
        }
        super.onDestroy();
    }

    @Override public IBinder onBind(Intent intent) { return null; }

    private class DuoView extends View {
        private final Paint paint = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final RectF rect = new RectF();
        private final float density;

        DuoView(Context context) {
            super(context);
            density = getResources().getDisplayMetrics().density;
            setLayerType(View.LAYER_TYPE_HARDWARE, null);
            setOnClickListener(v -> {
                expanded = !expanded;
                updateWindowSize();
            });
            setContentDescription("Status Duo: pin " + batteryPercent + "%, Wi-Fi " + wifiLabel() + ", sóng di động " + cellLabel());
        }

        private void stroke(Paint p, int color, float width) {
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(width * density);
            p.setStrokeCap(Paint.Cap.ROUND);
            p.setColor(color);
        }

        private int dimColor() { return 0x66FFFFFF; }
        private int activeColor() { return Color.WHITE; }

        @Override protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            if (expanded) drawExpanded(canvas); else drawCompact(canvas);
            setContentDescription("Status Duo: pin " + batteryPercent + "%, Wi-Fi " + wifiLabel() + ", sóng di động " + cellLabel());
        }

        private void drawCompact(Canvas canvas) {
            drawIndicatorIcon(canvas, getWidth() / 2f, getHeight() / 2f, Math.min(getWidth(), getHeight()));
        }

        private void drawIndicatorIcon(Canvas canvas, float cx, float cy, float diameter) {
            float r = diameter * 0.43f;
            paint.setStyle(Paint.Style.FILL);
            paint.setColor(0xEE080A0D);
            canvas.drawCircle(cx, cy, r + dp(1), paint);

            // Battery ring: the lit arc tracks the real charge percentage.
            stroke(paint, 0x55FFFFFF, 1.8f);
            rect.set(cx - r, cy - r, cx + r, cy + r);
            // Leave a small opening at the bottom, like the iPhone Duo-style ring.
            canvas.drawArc(rect, 105, 330, false, paint);
            int ringColor = batteryPercent <= 15 ? 0xFFFF5C5C : (isCharging ? 0xFF65E58A : Color.WHITE);
            stroke(paint, ringColor, 2.0f);
            canvas.drawArc(rect, 105, 3.3f * batteryPercent, false, paint);

            // Wi-Fi arcs at the top; the number of lit arcs follows the real RSSI level.
            float wifiCy = cy - dp(7.4f);
            for (int i = 1; i <= 3; i++) {
                float radius = dp(1.5f + i * 1.2f);
                rect.set(cx - radius, wifiCy - radius, cx + radius, wifiCy + radius);
                boolean active = wifiConnected && wifiLevel >= i;
                stroke(paint, active ? activeColor() : dimColor(), 1.15f);
                canvas.drawArc(rect, -135, 90, false, paint);
            }

            // Battery percentage sits in the centre; charging is also shown with a tiny bolt.
            paint.setStyle(Paint.Style.FILL);
            paint.setColor(batteryPercent <= 15 ? 0xFFFF6B6B : Color.WHITE);
            paint.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
            paint.setTextAlign(Paint.Align.CENTER);
            paint.setTextSize(dp(batteryPercent >= 100 ? 7.4f : 8.5f));
            canvas.drawText(String.valueOf(batteryPercent), cx, cy + dp(6.3f), paint);
            if (isCharging) {
                paint.setColor(0xFF65E58A);
                PathBolt.draw(canvas, paint, cx + dp(8.5f), cy - dp(6.5f), dp(3.4f));
            }

            // Four bottom dots represent the cellular signal level.
            float spacing = dp(3.4f);
            float dotY = cy + dp(11.2f);
            for (int i = 0; i < 4; i++) {
                paint.setStyle(Paint.Style.FILL);
                paint.setColor(cellularLevel >= 0 && cellularLevel >= i + 1 ? activeColor() : dimColor());
                canvas.drawCircle(cx + (i - 1.5f) * spacing, dotY, dp(1.15f), paint);
            }
        }

        private void drawExpanded(Canvas canvas) {
            float w = getWidth(), h = getHeight();
            float pad = dp(4);
            paint.setStyle(Paint.Style.FILL);
            paint.setColor(0xF2090B0E);
            rect.set(pad, pad, w - pad, h - pad);
            canvas.drawRoundRect(rect, dp(25), dp(25), paint);

            float diameter = dp(44);
            drawIndicatorIcon(canvas, dp(23), h / 2f, diameter);

            float textX = dp(53);
            paint.setTypeface(Typeface.create("sans-serif-medium", Typeface.NORMAL));
            paint.setTextAlign(Paint.Align.LEFT);
            paint.setTextSize(dp(11));
            paint.setColor(Color.WHITE);
            String battery = "Pin " + batteryPercent + "%" + (isCharging ? "  ⚡ Đang sạc" : "");
            canvas.drawText(battery, textX, dp(24), paint);
            paint.setTypeface(Typeface.create("sans-serif", Typeface.NORMAL));
            paint.setTextSize(dp(9.5f));
            paint.setColor(0xFFDFDFDF);
            canvas.drawText("Wi-Fi: " + wifiLabel(), textX, dp(42), paint);
            canvas.drawText("Di động: " + cellLabel(), textX, dp(58), paint);
            if (batteryTemperatureC >= 0) {
                paint.setColor(0xFFAAAAAA);
                paint.setTextSize(dp(8.5f));
                canvas.drawText("Pin " + batteryTemperatureC + "°C", textX, dp(73), paint);
            }
        }
    }

    /** Tiny custom lightning glyph; avoids fonts/emojis changing across Android devices. */
    private static final class PathBolt {
        static void draw(Canvas canvas, Paint paint, float x, float y, float size) {
            android.graphics.Path path = new android.graphics.Path();
            path.moveTo(x + size * 0.15f, y - size);
            path.lineTo(x - size * 0.55f, y + size * 0.05f);
            path.lineTo(x - size * 0.08f, y + size * 0.05f);
            path.lineTo(x - size * 0.22f, y + size);
            path.lineTo(x + size * 0.55f, y - size * 0.15f);
            path.lineTo(x + size * 0.10f, y - size * 0.15f);
            path.close();
            canvas.drawPath(path, paint);
        }
    }
}
