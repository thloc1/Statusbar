package com.statusduo;
import android.content.*;import android.provider.Settings;import android.net.Uri;import android.service.quicksettings.Tile;import android.service.quicksettings.TileService;import android.os.Build;
public class StatusTileService extends TileService{
 @Override public void onClick(){super.onClick();if(!Settings.canDrawOverlays(this)){Intent i=new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,Uri.parse("package:"+getPackageName()));startActivityAndCollapse(i);return;}Intent s=new Intent(this,OverlayService.class);if(Build.VERSION.SDK_INT>=26)startForegroundService(s);else startService(s);getQsTile().setState(Tile.STATE_ACTIVE);getQsTile().updateTile();}
}
