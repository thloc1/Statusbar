package com.statusduo;

import android.Manifest;
import android.app.Activity;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Color;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

public class MainActivity extends Activity {
    private static final int REQ_PHONE_STATE = 301;
    private LinearLayout root;
    private TextView permissionStatus;

    @Override public void onCreate(Bundle state) {
        super.onCreate(state);
        buildUi();
    }

    private int dp(float n) {
        return (int) (n * getResources().getDisplayMetrics().density + 0.5f);
    }

    private TextView text(String value, float size, int color) {
        TextView t = new TextView(this);
        t.setText(value);
        t.setTextSize(size);
        t.setTextColor(color);
        return t;
    }

    private void buildUi() {
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(24), dp(32), dp(24), dp(24));
        root.setBackgroundColor(Color.rgb(10, 12, 16));

        TextView title = text("Status Duo 3.1.0", 28, Color.WHITE);
        title.setTypeface(android.graphics.Typeface.create("sans-serif-medium", 0));
        root.addView(title);

        TextView subtitle = text("Pin + Wi‑Fi + sóng di động\nMột biểu tượng gộp kiểu iPhone Duo", 15, 0xFFBFC5D0);
        LinearLayout.LayoutParams subParams = new LinearLayout.LayoutParams(-1, -2);
        subParams.topMargin = dp(8);
        root.addView(subtitle, subParams);

        // A real Canvas preview of the combined indicator (sample values only).
        PreviewView preview = new PreviewView(this);
        preview.setBackgroundColor(0xFF171A20);
        LinearLayout.LayoutParams previewParams = new LinearLayout.LayoutParams(-1, dp(100));
        previewParams.topMargin = dp(22);
        previewParams.bottomMargin = dp(12);
        root.addView(preview, previewParams);

        permissionStatus = text("", 13, 0xFFBFC5D0);
        LinearLayout.LayoutParams stateParams = new LinearLayout.LayoutParams(-1, -2);
        stateParams.bottomMargin = dp(8);
        root.addView(permissionStatus, stateParams);

        Button overlay = new Button(this);
        overlay.setText("① Cấp quyền hiển thị trên ứng dụng khác");
        overlay.setOnClickListener(v -> openOverlayPermission());
        root.addView(overlay, matchWrap());

        Button phone = new Button(this);
        phone.setText("② Cấp quyền đọc mức sóng di động");
        phone.setOnClickListener(v -> requestPhoneState());
        LinearLayout.LayoutParams phoneParams = matchWrap();
        phoneParams.topMargin = dp(8);
        root.addView(phone, phoneParams);

        Button start = new Button(this);
        start.setText("③ Bật / tắt chỉ báo Status Duo");
        start.setOnClickListener(v -> toggleService());
        LinearLayout.LayoutParams startParams = matchWrap();
        startParams.topMargin = dp(8);
        root.addView(start, startParams);

        TextView note = text("Quyền điện thoại chỉ dùng để đọc mức sóng di động. Ứng dụng không cần Internet hoặc vị trí. Nếu từ chối quyền điện thoại, pin và Wi‑Fi vẫn có thể hiển thị; cột sóng sẽ ở trạng thái chưa có dữ liệu.", 12, 0xFF9299A5);
        LinearLayout.LayoutParams noteParams = new LinearLayout.LayoutParams(-1, -2);
        noteParams.topMargin = dp(20);
        root.addView(note, noteParams);

        setContentView(root);
        refreshStatus();
    }

    private LinearLayout.LayoutParams matchWrap() {
        return new LinearLayout.LayoutParams(-1, -2);
    }

    private void openOverlayPermission() {
        if (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(this)) {
            Intent intent = new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                    Uri.parse("package:" + getPackageName()));
            startActivity(intent);
        } else {
            Toast.makeText(this, "Quyền hiển thị đã sẵn sàng", Toast.LENGTH_SHORT).show();
        }
    }

    private void requestPhoneState() {
        if (Build.VERSION.SDK_INT >= 23 && checkSelfPermission(Manifest.permission.READ_PHONE_STATE)
                != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.READ_PHONE_STATE}, REQ_PHONE_STATE);
        } else {
            Toast.makeText(this, "Đã có quyền đọc mức sóng", Toast.LENGTH_SHORT).show();
        }
    }

    private void toggleService() {
        if (OverlayService.running) {
            stopService(new Intent(this, OverlayService.class));
            Toast.makeText(this, "Đã tắt chỉ báo Status Duo", Toast.LENGTH_SHORT).show();
            return;
        }
        if (Build.VERSION.SDK_INT >= 23 && !Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Hãy cấp quyền hiển thị ở bước ① trước", Toast.LENGTH_LONG).show();
            openOverlayPermission();
            return;
        }
        boolean phoneOk = Build.VERSION.SDK_INT < 23 || checkSelfPermission(Manifest.permission.READ_PHONE_STATE)
                == PackageManager.PERMISSION_GRANTED;
        Intent intent = new Intent(this, OverlayService.class);
        if (Build.VERSION.SDK_INT >= 26) startForegroundService(intent); else startService(intent);
        String message = phoneOk
                ? "Đã bật chỉ báo. Chạm vào chỉ báo để mở rộng"
                : "Đã bật pin và Wi‑Fi. Cấp quyền ② để đọc mức sóng di động";
        Toast.makeText(this, message, Toast.LENGTH_LONG).show();
    }

    private void refreshStatus() {
        if (permissionStatus == null) return;
        boolean overlayOk = Build.VERSION.SDK_INT < 23 || Settings.canDrawOverlays(this);
        boolean phoneOk = Build.VERSION.SDK_INT < 23 || checkSelfPermission(Manifest.permission.READ_PHONE_STATE)
                == PackageManager.PERMISSION_GRANTED;
        permissionStatus.setText("Hiển thị nổi: " + (overlayOk ? "Đã cấp" : "Chưa cấp")
                + "\nĐọc sóng di động: " + (phoneOk ? "Đã cấp" : "Chưa cấp"));
    }

    @Override protected void onResume() {
        super.onResume();
        refreshStatus();
    }

    @Override public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_PHONE_STATE) {
            refreshStatus();
            if (grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED) {
                Toast.makeText(this, "Đã cấp quyền mức sóng di động", Toast.LENGTH_SHORT).show();
            } else {
                Toast.makeText(this, "Bạn vẫn có thể dùng pin và Wi‑Fi; sóng di động cần quyền này", Toast.LENGTH_LONG).show();
            }
        }
    }

    private class PreviewView extends View {
        private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final RectF r = new RectF();
        PreviewView(android.content.Context context) { super(context); }

        @Override protected void onDraw(Canvas c) {
            super.onDraw(c);
            float cx = getWidth() / 2f, cy = getHeight() / 2f;
            float radius = dp(22);
            p.setStyle(Paint.Style.FILL);
            p.setColor(0xFF080A0D);
            c.drawCircle(cx, cy, radius, p);
            r.set(cx - dp(18), cy - dp(18), cx + dp(18), cy + dp(18));
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeCap(Paint.Cap.ROUND);
            p.setStrokeWidth(dp(1.8f));
            p.setColor(0x66FFFFFF);
            c.drawArc(r, 105, 330, false, p);
            p.setStrokeWidth(dp(2.0f));
            p.setColor(0xFFFFFFFF);
            c.drawArc(r, 105, 3.3f * 86, false, p);
            float wifiCy = cy - dp(7.5f);
            for (int i = 1; i <= 3; i++) {
                float rr = dp(1.5f + i * 1.2f);
                r.set(cx - rr, wifiCy - rr, cx + rr, wifiCy + rr);
                p.setColor(0xFFFFFFFF);
                p.setStrokeWidth(dp(1.15f));
                c.drawArc(r, -135, 90, false, p);
            }
            p.setStyle(Paint.Style.FILL);
            p.setColor(Color.WHITE);
            p.setTextAlign(Paint.Align.CENTER);
            p.setTypeface(android.graphics.Typeface.create("sans-serif-medium", 0));
            p.setTextSize(dp(8.5f));
            c.drawText("86", cx, cy + dp(6.3f), p);
            for (int i = 0; i < 4; i++) {
                p.setColor(i < 3 ? Color.WHITE : 0x66FFFFFF);
                c.drawCircle(cx + (i - 1.5f) * dp(3.4f), cy + dp(11.2f), dp(1.15f), p);
            }
            p.setStyle(Paint.Style.FILL);
            p.setColor(0xFFBFC5D0);
            p.setTextSize(dp(10));
            c.drawText("Mô phỏng biểu tượng", cx, getHeight() - dp(8), p);
        }
    }

}
