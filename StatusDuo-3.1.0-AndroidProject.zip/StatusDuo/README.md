# Status Duo 3.1.0 — iPhone Duo-inspired indicator

Bản Android độc lập mô phỏng biểu tượng gộp **pin + Wi‑Fi + sóng di động** theo phong cách iPhone Duo.

## Biểu tượng
- Vòng ngoài biểu thị phần trăm pin; pin yếu chuyển đỏ, khi sạc chuyển xanh và có tia sét.
- Các cung phía trên biểu thị cường độ Wi‑Fi thực tế.
- Bốn chấm phía dưới biểu thị mức sóng di động thực tế của SIM mặc định.
- Chạm biểu tượng để mở bảng chi tiết pin, Wi‑Fi và sóng di động.
- Cập nhật theo sự kiện của Android, Wi‑Fi và sóng di động; không chạy vòng lặp cập nhật liên tục.

## Quyền
- **Hiển thị trên ứng dụng khác:** cần để hiện biểu tượng nổi.
- **Trạng thái điện thoại:** chỉ dùng để đọc mức sóng di động. Nếu từ chối, pin và Wi‑Fi vẫn dùng được, còn mức sóng di động sẽ không có dữ liệu.
- Không yêu cầu quyền Internet hoặc vị trí.

## Cập nhật repo GitHub đang dùng trong hướng dẫn
Nếu repo của bạn đang có workflow giải nén `StatusDuo-3.1.0-AndroidProject.zip`, hãy tải bản ZIP này lên repo với **đúng tên `StatusDuo-3.1.0-AndroidProject.zip`**, thay thế file cũ ở thư mục gốc rồi commit. Workflow cũ sẽ giải nén và tìm `settings.gradle` để build.

Nếu bạn muốn dùng dự án như một repo Android Studio độc lập, hãy giải nén thư mục `StatusDuo` và tải **các nội dung bên trong thư mục đó** lên thư mục gốc repo, bao gồm `.github/workflows/build-apk.yml`.

Sau khi build xong, vào **Actions → lần chạy mới nhất → Artifacts** và tải artifact APK.

## Giới hạn cần biết
Đây là **biểu tượng nổi mô phỏng**, không phải chỉnh sửa trực tiếp Samsung One UI SystemUI để thay thế các icon gốc trong thanh trạng thái. Ứng dụng Android thông thường không thể tự thay thế icon hệ thống theo cách tích hợp hoàn toàn như trên iPhone Duo; bản này ưu tiên hiển thị được mà không yêu cầu root hoặc LSPosed.
